package io.keepcoding.spark.exercise.batch
import org.apache.spark.sql.functions.{avg, lit, max, min, sum, window}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import java.time.OffsetDateTime


object BatchJobImpl {

  // Iniciamos la sesion de Spark:
  val spark: SparkSession = SparkSession
    .builder()
    .master("local[*]")
    .getOrCreate()

  import spark.implicits._

  // Leemos datos de Storage:
  def readFromStorage(storagePath: String, filterDate: OffsetDateTime): DataFrame = {
    spark
      .read
      .format("parquet")
      .load(storagePath)
      .where(
          $"year" === lit(filterDate.getYear) &&
            $"month" === lit(filterDate.getMonthValue) &&
            $"day" === lit(filterDate.getDayOfMonth) &&
            $"hour" === lit(filterDate.getHour)
      )
  }

  // Leemos datos del postgreSQL:
  def readDevicesMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }

  // Combinamos datos del postgreSQL con los del flujo de Kafka:
  def enrichDevicesWithMetadata(devicesDF: DataFrame, metadataDF: DataFrame): DataFrame = {
    devicesDF.as("a")
      .join(metadataDF.as("b"), $"a.id" === $"b.id" )
      .drop($"b.id")
  }

  // Queries:
  def totalBytes (data: DataFrame, groupCol: String, metric: String, date: OffsetDateTime): DataFrame =  {
    data
      .select(col(groupCol).as("id"), $"bytes")
      .groupBy($"id")
      .agg(sum($"bytes").as("total_bytes"))
      .withColumn("type", lit(metric))
      .withColumn("timestamp", lit(date.toEpochSecond).cast(TimestampType))
  }

  // Escribimos las tablas generadas en el postgreSQL:
  def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Unit = {
    dataFrame
      .write
      .mode(SaveMode.Append)
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .save()
  }


  def main (args: Array[String]): Unit = {

    val jdbcURI = "jdbc:postgresql://34.88.254.131:5432/postgres"
    val user = "postgres"
    val password = "keepcoding"
    val date = OffsetDateTime.parse("2022-02-27T22:00:00Z")

    val rawDF = readFromStorage("/Users/luis/Documents/KeepCoding/Github/Big-Data-Processing/big-data-processing/entrega-final-luismartin/exercise/src/main/resources/output/data",
      OffsetDateTime.parse("2022-02-27T21:00:00Z"))

    val totalBytesAntenna = totalBytes(rawDF, "antenna_id", "total_antenna_bytes", date)
    writeToJdbc(totalBytesAntenna, jdbcURI, "batch_bytes_antenna", user, password)

    val totalBytesUser = totalBytes(rawDF, "id", "total_user_bytes", date)
    writeToJdbc(totalBytesAntenna, jdbcURI, "batch_bytes_user", user, password)

    val totalBytesApp = totalBytes(rawDF, "app", "total_app_bytes", date)
    writeToJdbc(totalBytesAntenna, jdbcURI, "batch_bytes_app", user, password)


    val metadataDF = readDevicesMetadata(
      "jdbc:postgresql://34.88.254.131:5432/postgres",
      "user_metadata",
      "postgres",
      "keepcoding")

    val user_quota = enrichDevicesWithMetadata(
      totalBytesUser.as("userBytes")
      .select($"id", $"total_bytes"),
      metadataDF)
      .select($"b.email".as("email"), $"a.total_bytes".as("usage"), $"b.quota".as("quota"))
      .where($"usage" > $"b.quota")

    writeToJdbc(user_quota, jdbcURI, "user_quota_limit", user, password)

  }
}
