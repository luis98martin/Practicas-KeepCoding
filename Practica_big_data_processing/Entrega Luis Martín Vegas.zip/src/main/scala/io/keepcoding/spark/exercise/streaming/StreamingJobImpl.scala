package io.keepcoding.spark.exercise.streaming
import io.netty.handler.codec.spdy.SpdyDataFrame
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

object StreamingJobImpl {

  // Iniciamos la sesion de Spark:
  val spark: SparkSession = SparkSession
    .builder()
    .master("local[*]")
    .getOrCreate()

  import spark.implicits._

  // Leemos de Kafka:
  def readFromKafka(kafkaServer: String, topic: String): DataFrame = {
    spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("subscribe", topic)
      .load()
  }

  // Parseamos los datos:
  def parserJsonData(dataFrame: DataFrame): DataFrame = {

    val struct = StructType(Seq(
      StructField("timestamp", TimestampType, nullable = false),
      StructField("id", StringType, nullable = false),
      StructField("antenna_id", StringType, nullable = false),
      StructField("bytes", LongType, nullable = false),
      StructField("app", StringType, nullable = false)
    ))

    dataFrame
      .select(from_json($"value".cast(StringType), struct).as("value"))
      .select($"value.*") // Subimos todos los datos un nivel
    // .withColumn("timestamp", $"timestamp".cast(TimestampType)) Se puede pasar a timestamp así también.
  }

  // Leemos datos del postgreSQL:
  def readDevicesMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }

  // Combinamos datos del postgreSQL con los del flujo de Kafka:
  def enrichDevicesWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame = {
    antennaDF.as("a")
      .join(metadataDF.as("b"), $"a.id" === $"b.id")
      .drop($"b.id")
  }

  // Queries:
  def totalBytesAntenna (data: DataFrame, jdbcConnection: String): Future[Unit] = Future {

    data
      .select($"timestamp", $"antenna_id", $"id", $"app", $"bytes")
      .withWatermark("timestamp", "15 seconds")
      .groupBy(window($"timestamp", "90 seconds"), $"antenna_id")
      .agg(sum($"bytes").as("total_bytes"))
      .select(
        $"window.start".as("timestamp"),
        $"antenna_id".as("id"),
        $"total_bytes".as("value"),
        lit("antenna" + "_total_bytes").as("type")
      )
      .writeStream
      .foreachBatch((dataset: DataFrame, batchId: Long) =>
        dataset
          .write
          .mode(SaveMode.Append)
          .format("jdbc")
          .option("driver", "org.postgresql.Driver")
          .option("url", jdbcConnection)
          .option("dbtable", "antenna_bytes")
          .option("user", "postgres")
          .option("password", "keepcoding")
          .save()
      )
      .start()
      .awaitTermination()
  }
  def totalBytesUser (data: DataFrame, jdbcConnection: String): Future[Unit] = Future {

    data
      .select($"timestamp", $"antenna_id", $"id", $"app", $"bytes")
      .withWatermark("timestamp", "15 seconds")
      .groupBy(window($"timestamp", "90 seconds"), $"id")
      .agg(sum($"bytes").as("total_bytes"))
      .select(
        $"window.start".as("timestamp"),
        $"id",
        $"total_bytes".as("value"),
        lit("user" + "_total_bytes").as("type")
      )
      .writeStream
      .foreachBatch((dataset: DataFrame, batchId: Long) =>
        dataset
          .write
          .mode(SaveMode.Append)
          .format("jdbc")
          .option("driver", "org.postgresql.Driver")
          .option("url", jdbcConnection)
          .option("dbtable", "user_bytes")
          .option("user", "postgres")
          .option("password", "keepcoding")
          .save()
      )
      .start()
      .awaitTermination()
  }
  def totalBytesApp (data: DataFrame, jdbcConnection: String): Future[Unit] = Future {

    data
      .select($"timestamp", $"antenna_id", $"id", $"app", $"bytes")
      .withWatermark("timestamp", "15 seconds")
      .groupBy(window($"timestamp", "90 seconds"), $"app")
      .agg(sum($"bytes").as("total_bytes"))
      .select(
        $"window.start".as("timestamp"),
        $"app",
        $"total_bytes".as("value"),
        lit("app" + "_total_bytes").as("type")
      )
      .writeStream
      .foreachBatch((dataset: DataFrame, batchId: Long) =>
        dataset
          .write
          .mode(SaveMode.Append)
          .format("jdbc")
          .option("driver", "org.postgresql.Driver")
          .option("url", jdbcConnection)
          .option("dbtable", "app_bytes")
          .option("user", "postgres")
          .option("password", "keepcoding")
          .save()
      )
      .start()
      .awaitTermination()
  }

  // Guardamos los datos generados en local, en disco (particionado por año/mes/dia/hora):
  def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Future[Unit] = Future {
    dataFrame
      .withColumn("year", year($"timestamp"))
      .withColumn("month", month($"timestamp"))
      .withColumn("day", dayofyear($"timestamp"))
      .withColumn("hour", hour($"timestamp"))
      .writeStream
      .partitionBy("year", "month", "day", "hour")
      .format("parquet")
      .option("path", storageRootPath + "/data")
      .option("checkpointLocation", storageRootPath + "/checkpoint")
      .start()
      .awaitTermination()
  }

  def main(args: Array[String]): Unit = {

    val metadataDF = readDevicesMetadata(
      "jdbc:postgresql://34.88.254.131:5432/postgres",
      "user_metadata",
      "postgres",
      "keepcoding"
    )

    val antennaBytes = totalBytesAntenna(
      parserJsonData(
        readFromKafka("34.88.69.200:9092", "devices")),
       "jdbc:postgresql://34.88.254.131:5432/postgres")

    val userBytes = totalBytesUser(
      parserJsonData(
        readFromKafka("34.88.69.200:9092", "devices")),
      "jdbc:postgresql://34.88.254.131:5432/postgres")

    val appBytes = totalBytesApp(
      parserJsonData(
        readFromKafka("34.88.69.200:9092", "devices")),
      "jdbc:postgresql://34.88.254.131:5432/postgres")

    val localCopy = writeToStorage(
        parserJsonData(
          readFromKafka("34.88.69.200:9092", "devices")),
      "/Users/luis/Documents/KeepCoding/Github/Big-Data-Processing/big-data-processing/entrega-final-luismartin/exercise/src/main/resources/output"
    )

    Await.result(Future.sequence(Seq(antennaBytes, userBytes, appBytes)), Duration.Inf)
  }
}